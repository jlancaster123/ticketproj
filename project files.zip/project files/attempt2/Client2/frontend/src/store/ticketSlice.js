import { createSlice } from "@reduxjs/toolkit";

const ticketSlice = createSlice({
  name: "ticket",
  initialState: {
    ticketHistory: false,
    viewTicket: false,
    addNewTicket: false,
  },
  reducers: {
    findTicketHistory(state) {
      state.ticketHistory = true;
    },
    viewExistingTicket(state) {
      state.viewTicket = true;
    },
    addNewTicket(state) {
      state.addNewTicket = true;
    },
  },
});

export const ticketActions = ticketSlice.actions;

export default ticketSlice;
