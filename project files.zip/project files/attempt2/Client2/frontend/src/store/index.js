import { configureStore, createSlice } from "@reduxjs/toolkit";
import loginSlice from "./loginSlice";
import searchSlice from "./searchSlice";

const store = configureStore({
  reducer: {
    login: loginSlice.reducer,
    search: searchSlice.reducer,
  },
});
export default store;
