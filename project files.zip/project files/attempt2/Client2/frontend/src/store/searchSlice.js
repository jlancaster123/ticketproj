import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";
// import Customer from "../../../../Server2/models/customerModel";

const searchSlice = createSlice({
  name: "search",
  initialState: {
    foundCustomer: false,
    mapCustomer: false,
    searchState: false,
    displayCustomer: false,
    updateTicket: "",
  },
  reducers: {
    findCustomer(state) {
      state.foundCustomer = true;
    },
    displayCustomer(state) {
      state.displayCustomer = true;
    },
    mapCustomer(state) {
      state.mapCustomer = true;
    },
    searchTicket(state) {
      state.searchState = true;
    },
    searchCustomerId(state) {
      state.searchState = true;
    },
    searchState(state) {
      state.searchState = true;
    },
    updateTicket(state, payload) {
      console.log(payload);
      state.updateTicket = payload;
    },
  },
});

export const searchActions = searchSlice.actions;

export default searchSlice;
