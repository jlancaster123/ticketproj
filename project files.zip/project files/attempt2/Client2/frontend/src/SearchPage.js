import Customer from "./Customer";
import { useDispatch, useSelector } from "react-redux";

import { searchActions } from "./store/searchSlice";
import { TextField, Button, gridClasses } from "@mui/material";
import { useState, useMemo, useCallback, useRef, useEffect } from "react";
import axios from "axios";
import CustomerOptions from "./CustomerOptions";
import AddCustomer from "./AddCustomer";
import style from "./SearchPage.css";
import CustomerTable from "./CustomerTable";
import AddTicket from "./AddTicket";

function SearchPage() {
  const displayCustomer = useSelector((state) => state.search.displayCustomer);
  // const customer = useSelector((state) => state.search.customer);
  const [customer, setCustomer] = useState([]);

  const dispatch = useDispatch();
  const [page, setPage] = useState("home");
  // const searchForCustomer = () => {
  //   return dispatch(searchActions.findCustomer());
  // };
  // const mapCustomer = () => {
  //   return dispatch(searchActions.mapCustomer());
  // };

  const handleSubmitTicket = async (e) => {
    try {
      e.preventDefault();

      console.log(inputs);
      dispatch(searchActions.searchCustomerId());

      await axios
        .post("http://localhost:5000/api/find", { ticketId: inputs.ticketId })
        .then((response) => {
          console.log(response);
          setCustomer(response.data);
        })
        .then(dispatch(searchActions.displayCustomer()));
    } catch (error) {
      console.log(error);
    }
  };
  const handleSubmitCustomerId = async (e) => {
    try {
      e.preventDefault();

      console.log(inputs);
      dispatch(searchActions.searchCustomerId());

      await axios
        .post("http://localhost:5000/api/find", {
          customerId: inputs.customerId,
        })
        .then((response) => {
          console.log(response);
          setCustomer(response.data);
        })
        .then(dispatch(searchActions.displayCustomer()))
        .then(() => {
          if (customer[0]) {
            setPage("home");
          }
        });
    } catch (error) {
      console.log(error);
    }
  };
  const handleSubmitCustomerFirstName = async (e) => {
    try {
      e.preventDefault();

      console.log(inputs);
      dispatch(searchActions.searchCustomerId());

      const temp = await axios
        .post("http://localhost:5000/api/find", {
          firstName: inputs.customerFirstName,
        })
        .then((response) => {
          console.log(response);
          return response.data;
        });
      setCustomer(temp);
      console.log(customer);
      dispatch(searchActions.displayCustomer());
      if (customer[0]) {
        setPage("home");
      }
    } catch (error) {
      console.log(error);
    }
  };

  const handleChange = (e) => {
    setInputs((prevState) => ({
      ...prevState,
      [e.target.name]: [e.target.value],
    }));
  };

  useEffect(() => {
    console.log(customer);
    if (customer[0]) {
      setPage("customer");
    }
  }, [customer]);

  useEffect(() => {
    console.log(page);
  }, [page]);
  const mapCustomer = async (e) => {
    try {
      e.preventDefault();

      console.log(inputs);
      dispatch(searchActions.searchCustomerId());

      const temp = await axios
        .post("http://localhost:5000/api/find", {})
        .then((response) => {
          console.log(response);
          // return response.data;
          setCustomer(response.data);
        });

      // console.log(customer.data);

      dispatch(searchActions.displayCustomer());
    } catch (error) {
      console.log(error);
    }
  };

  const [inputs, setInputs] = useState({
    id: "",
    customerId: "",
    customerFirstName: "",
  });
  const columnDefs = [
    { field: "firstName" },
    { field: "lastName" },
    { field: "_id" },
  ];
  const columnDefTicket = [
    { field: "ticketId" },
    { field: "ticketStatus" },
    { field: "_id" },
  ];
  const defaultColDef = useMemo(() => ({
    sortable: true,
    filter: true,
  }));
  const backClick = () => {
    setPage("home");
  };
  const backClickCustomer = () => {
    setPage("customer");
  };

  const gridRef = useRef();
  const [selectedRows, setSelectedRows] = useState();

  const viewClick = async (e) => {
    const temp = gridRef.current.api.getSelectedRows();
    console.log(temp);
    if (temp.length != 0) {
      const id = temp[0]._id;
      console.log(id);
      const temp2 = await axios
        .post("http://localhost:5000/api/findTicket", { _id: id })
        .then((response) => {
          console.log(response);
          return response.data;
        });
      console.log(temp2);

      // console.log(selectedRows[0].ticketList);
      if (temp2[0].ticketList.length !== 0) {
        setSelectedRows(temp2[0].ticketList);
        setPage("tickets");
      }
    }
  };

  const addTicketClick = () => {
    setPage("addTicket");
  };

  const editTicketClick = () => {
    setPage("editTicket");
  };

  return (
    <div className="homepage">
      {page === "home" && (
        <div>
          <h2 className="search">
            Ticket search by Id
            <form onSubmit={handleSubmitTicket}>
              <TextField
                name="id"
                value={inputs.id}
                onChange={handleChange}
                placeholder="id"
                type="text"
                variant="outlined"
                sx={{
                  background: "white",
                  borderRadius: "30px",
                  border: "1.5px solid black",

                  "& fieldset": { border: "none" },
                }}
              />
              <Button variant="outlined" color="secondary" type="submit">
                Submit
              </Button>
            </form>
          </h2>
          <h2 className="search">
            Customer search by Id
            <form onSubmit={handleSubmitCustomerId}>
              <TextField
                name="customerId"
                value={inputs.customerId}
                onChange={handleChange}
                placeholder="customerId"
                type="text"
                variant="outlined"
                sx={{
                  background: "white",
                  border: "1.5px solid black",
                  borderRadius: "30px",
                  "& fieldset": { border: "none" },
                }}
              />
              <Button variant="outlined" color="secondary" type="submit">
                Submit
              </Button>
            </form>
          </h2>
          <h2 className="search">
            Customer search by firstName
            <form onSubmit={handleSubmitCustomerFirstName}>
              <TextField
                name="customerFirstName"
                value={inputs.customerFirstName}
                onChange={handleChange}
                placeholder="customerFirstName"
                type="text"
                variant="outlined"
                sx={{
                  background: "white",
                  borderRadius: "30px",
                  border: "1.5px solid black",

                  "& fieldset": { border: "none" },
                }}
              />

              <Button variant="outlined" color="secondary" type="submit">
                Submit
              </Button>
            </form>
          </h2>
          <h1 className="container">
            <AddCustomer />
            <Button
              flex={1}
              onClick={mapCustomer}
              variant="outlined"
              color="secondary"
              type="submit"
            >
              Display All Customers
            </Button>
          </h1>
        </div>
      )}
      <div>
        {page === "customer" && (
          <div>
            <Button
              onClick={backClick}
              variant="outlined"
              color="secondary"
              type="submit"
            >
              Back
            </Button>
            <CustomerTable
              gridRef={gridRef}
              rowData={customer}
              columnDefs={columnDefs}
              defaultColDef={defaultColDef}
            />
            <div className="CustomerTableDiv">
              <Button
                onClick={viewClick}
                variant="outlined"
                color="secondary"
                type="submit"
              >
                View Customer Tickets
              </Button>
              {/* <AddCustomer /> */}
            </div>
          </div>
        )}
        {page === "tickets" && (
          <div>
            <Button
              onClick={backClickCustomer}
              variant="outlined"
              color="secondary"
              type="submit"
            >
              Back
            </Button>
            <CustomerTable
              gridRef={gridRef}
              rowData={selectedRows}
              columnDefs={columnDefTicket}
              defaultColDef={defaultColDef}
            />
            <Button
              onClick={editTicketClick}
              variant="outlined"
              color="secondary"
              type="submit"
            >
              Edit Ticket
            </Button>
            <Button
              onClick={addTicketClick}
              variant="outlined"
              color="secondary"
              type="submit"
            >
              Add Ticket
            </Button>
          </div>
        )}
        {page === "addTicket" && (
          <div>
            <Button
              onClick={backClickCustomer}
              variant="outlined"
              color="secondary"
              type="submit"
            >
              Back
            </Button>
            <h1>imagine there is a form here thank you</h1>
            <AddTicket />
          </div>
        )}
        {page === "editTicket" && (
          <div>
            <Button
              onClick={backClickCustomer}
              variant="outlined"
              color="secondary"
              type="submit"
            >
              Back
            </Button>
            <h2>imagine there is a form to edit tickets here</h2>
          </div>
        )}
      </div>
    </div>
  );
}

export default SearchPage;
