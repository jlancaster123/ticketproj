import { TextField, Button } from "@mui/material";
import { useState } from "react";
import axios from "axios";

const UpdateTicket = () => {
  const [inputs, setInputs] = useState({
    ticketId: "",
    ticketStatus: "",
    ticketTypeName: "",
  });
  const handleChange = (e) => {
    setInputs((prevState) => ({
      ...prevState,
      [e.target.name]: e.target.value,
    }));
  };

  const handleSubmitAddTicket = async (e) => {
    e.preventDefault();
    // console.log(inputs);
    // console.log(customer.customer._id);

    // await axios
    //   .post("http://localhost:5000/api/addTicket", {
    //     _id: customer.customer._id,
    //     ticket: inputs,
    //   })
    //   .then((response) => {
    //     console.log(response);
    //     //   setCustomer(response.data);
    //   });
  };

  return (
    <div>
      update Ticket
      <form onSubmit={handleSubmitAddTicket}>
        <TextField
          name="ticketId"
          value={inputs.ticketId}
          onChange={handleChange}
          placeholder="id"
          type="text"
          variant="outlined"
        />
        <TextField
          name="ticketStatus"
          value={inputs.ticketStatus}
          onChange={handleChange}
          placeholder="ticketStatus"
          type="text"
          variant="outlined"
        />
        <TextField
          name="ticketTypeName"
          value={inputs.ticketTypeName}
          onChange={handleChange}
          placeholder="ticketTypeName"
          type="text"
          variant="outlined"
        />
        <Button type="submit">Submit</Button>
      </form>
    </div>
  );
};

export default UpdateTicket;
