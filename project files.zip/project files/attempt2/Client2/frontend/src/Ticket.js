const Ticket = (
  ticketId,
  ticketType,
  ticketStatus,
  closedDate,
  createdDate,
  createdBy,
  lastModifiedDate,
  lastModifiedBy,
  isActive
) => {
  return (
    <div>
      <h1>TicketId: {ticketId} </h1>
      <h1>TicketType: {ticketType} </h1>
      <h1>TicketStatus: {ticketStatus} </h1>
      <h1>ClosedDate: {closedDate} </h1>
      <h1>CreatedDate: {createdDate} </h1>
      <h1>CreatedBy: {createdBy} </h1>
      <h1>LastModifiedDate: {lastModifiedDate} </h1>
      <h1>LastModifiedBy: {lastModifiedBy} </h1>
      <h1>IsActive: {isActive} </h1>
    </div>
  );
};

export default Ticket;

// ticket:[{ ticketId, ticketType, status, closedDate, createdDate, createdBy, lastModifiedDate, lastModifiedBy, isActive}]
