import Customer from "./Customer";
import SearchPage from "./SearchPage";
import { useDispatch, useSelector } from "react-redux";
import { searchActions } from "./store/searchSlice";
import { TextField, Button } from "@mui/material";
import { useState } from "react";

function Webpage() {
  const dispatch = useDispatch();
  const foundCustomer = useSelector((state) => state.search.foundCustomer);
  const ismapCustomer = useSelector((state) => state.search.mapCustomer);
  const searchState = useSelector((state) => state.search.searchState);
  const searchPage = (e) => {
    e.preventDefault();
    // dispatch
    dispatch(searchActions.searchState());
  };
  return (
    <div>
      {!searchState && <Button onClick={searchPage}>Search?</Button>}
      {searchState && <SearchPage />}
      {ismapCustomer && <h1>map customers here</h1>}
      {foundCustomer && <Customer />}
    </div>
  );
}

export default Webpage;
