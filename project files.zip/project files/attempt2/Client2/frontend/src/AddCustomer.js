import { TextField, Button } from "@mui/material";
import { useState } from "react";
import axios from "axios";
const AddCustomer = () => {
  const [add, setAdd] = useState(false);

  const [inputs, setInputs] = useState({
    customerId: "",
    firstName: "",
    lastName: "",
  });
  const handleChange = (e) => {
    setInputs((prevState) => ({
      ...prevState,
      [e.target.name]: e.target.value,
    }));
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    const temp = JSON.stringify(inputs);
    console.log(temp);

    await axios
      .post("http://localhost:5000/api/addCustomer", { inputs })
      .then((response) => {
        console.log(response);
        //   setCustomer(response.data);
      });
  };

  const addClickState = () => {
    setAdd(!add);
    console.log(add);
  };

  const addClick = () => {
    return (
      <div>
        addCustomer
        <form onSubmit={handleSubmit}>
          <TextField
            name="customerId"
            value={inputs.customerId}
            onChange={handleChange}
            placeholder="id"
            type="text"
            variant="outlined"
          />
          <TextField
            name="firstName"
            value={inputs.firstName}
            onChange={handleChange}
            placeholder="firstName"
            type="text"
            variant="outlined"
          />
          <TextField
            name="lastName"
            value={inputs.lastName}
            onChange={handleChange}
            placeholder="lastName"
            type="text"
            variant="outlined"
          />
          <Button type="submit">Submit</Button>
        </form>
      </div>
    );
  };

  return (
    <div>
      <Button
        flex={1}
        onClick={addClickState}
        variant="outlined"
        color="secondary"
        type="submit"
      >
        Add Customer
      </Button>
      {add && addClick()}
    </div>
  );
};

export default AddCustomer;
