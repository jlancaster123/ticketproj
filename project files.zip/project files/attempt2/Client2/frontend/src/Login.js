import logo from "./logo.svg";
import { useDispatch } from "react-redux";
import { loginActions } from "./store/loginSlice";
import { TextField, Button } from "@mui/material";
import { useState } from "react";

function Login() {
  const dispatch = useDispatch();

  const loginButton = (e) => {
    e.preventDefault();
    // dispatch
    dispatch(loginActions.login());
  };

  //form handling
  const handleSubmit = (e) => {
    e.preventDefault();
    alert("submission!");
    console.log(inputs);
    dispatch(loginActions.login());
  };
  const handleChange = (e) => {
    setInputs((prevState) => ({
      ...prevState,
      [e.target.name]: [e.target.value],
    }));
  };

  const [inputs, setInputs] = useState({
    username: "",
    password: "",
  });

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <TextField
          name="username"
          value={inputs.username}
          onChange={handleChange}
          placeholder="username"
          type="text"
          variant="outlined"
        />
        <TextField
          name="password"
          value={inputs.password}
          onChange={handleChange}
          placeholder="password"
          type="text"
          variant="outlined"
        />
        <Button type="submit">Submit</Button>
      </form>
      <h1>{inputs.username}</h1>
      <h1>{inputs.password}</h1>
    </div>
  );
}

export default Login;

{
  /* <button onClick={loginButton}>login</button> */
}
