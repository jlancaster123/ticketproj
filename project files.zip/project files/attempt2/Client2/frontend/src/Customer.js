import Ticket from "./Ticket";

const Customer = () => {
  const displayHistory = () => {};
  const viewTicket = () => {};
  const addNewTicket = () => {};

  return (
    <div>
      <h1>customer</h1>
      <button onClick={displayHistory}>display ticket history</button>
      <button onClick={viewTicket}>view existing ticket</button>
      <button onClick={addNewTicket}>add new ticket</button>
    </div>
  );
};

export default Customer;
