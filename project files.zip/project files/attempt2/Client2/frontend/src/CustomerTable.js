import { useMemo } from "react";

import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css"; // Core grid CSS, always needed
import "ag-grid-community/styles/ag-theme-alpine.css"; // Optional theme CSS

const CustomerTable = ({ gridRef, rowData, columnDefs, defaultColDef }) => {
  return (
    <div className="ag-theme-alpine" style={{ width: 900, height: 500 }}>
      <AgGridReact
        ref={gridRef} // Ref for accessing Grid's API
        rowData={rowData} // Row Data for Rows
        columnDefs={columnDefs} // Column Defs for Columns
        defaultColDef={defaultColDef} // Default Column Properties
        animateRows={true} // Optional - set to 'true' to have rows animate when sorted
        rowSelection="single" // Options - allows click selection of rows
        pagination={true}
        paginationAutoPageSize={true}
        // onCellClicked={cellClickedListener} // Optional - registering for Grid Event
      />
    </div>
  );
};

export default CustomerTable;
