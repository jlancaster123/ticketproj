import TicketForms from "./TicketForms";
import { useState } from "react";
const AddTicket = () => {
  const [dropDown, setDropDown] = useState([]);
  return (
    <div>
      <TicketForms dropDown={dropDown} setDropDown={setDropDown} />;
    </div>
  );
};

export default AddTicket;
