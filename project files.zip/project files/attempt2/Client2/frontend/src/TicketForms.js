import { dividerClasses } from "@mui/material";
import Select from "react-select";
import { useState } from "react";
import { Button } from "@mui/material";

const TicketForms = ({ dropDown, setDropDown }) => {
  const [selectedValue1, setSelectedValue1] = useState(false);
  const [selectedValue2, setSelectedValue2] = useState(false);
  const [selectedValue3, setSelectedValue3] = useState(false);

  const options1 = [
    { value: "questionDropDown1", label: "questionDropDown1" },
    { value: "questionDropDown2", label: "questionDropDown2" },
    { value: "questionDropDown3", label: "questionDropDown3" },
  ];
  const options2 = [
    { value: "questionDropDown4", label: "questionDropDown4" },
    { value: "questionDropDown5", label: "questionDropDown5" },
    { value: "questionDropDown6", label: "questionDropDown6" },
  ];
  const options3 = [
    { value: "questionDropDown7", label: "questionDropDown7" },
    { value: "questionDropDown8", label: "questionDropDown8" },
    { value: "questionDropDown9", label: "questionDropDown9" },
  ];
  // const onInputChange = (value) => {
  //   setValue(value);
  //   console.log(value);
  // };
  const changeValue = (index, value) => {
    setDropDown((existingItems) => {
      return [
        ...existingItems.slice(0, index),
        value,
        ...existingItems.slice(index + 1),
      ];
    });
    console.log(dropDown);
  };
  const onSelectChange1 = (value) => {
    setSelectedValue1(value);
    changeValue(0, value);
    // console.log("changed value");
    // console.log(value);
  };
  const onSelectChange2 = (value) => {
    setSelectedValue2(value);
    changeValue(1, value);
    // console.log(value);
  };
  const onSelectChange3 = (value) => {
    setSelectedValue3(value);
    changeValue(2, value);
    // console.log(value);
  };
  return (
    <div>
      <Select
        options={options1}
        value={selectedValue1}
        onChange={onSelectChange1}
      />

      {selectedValue1.value === "questionDropDown1" && (
        <Select
          options={options2}
          value={selectedValue2}
          onChange={onSelectChange2}
        />
      )}
      {selectedValue1.value === "questionDropDown1" && (
        <Select
          options={options3}
          value={selectedValue3}
          onChange={onSelectChange3}
        />
      )}
      <Button variant="outlined" size="small">
        submit
      </Button>
    </div>
  );
};

export default TicketForms;
