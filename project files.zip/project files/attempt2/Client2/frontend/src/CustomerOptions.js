import { TextField, Button } from "@mui/material";
import { useState } from "react";
import axios from "axios";
import { searchActions } from "./store/searchSlice";
import { useDispatch } from "react-redux";
import { useSelector } from "react-redux";
import UpdateTicket from "./UpdateTicket";
import Select from "react-select";
import TicketForms from "./TicketForms";
import cust from "./CustomerOptions.css";
const CustomerOptions = (customer) => {
  const [history, setHistory] = useState(false);
  const [add, setAdd] = useState(false);
  const dispatch = useDispatch();
  const updateTicket = useSelector((state) => state.search.updateTicket);
  const [ticketInfo, setTicketInfo] = useState(false);
  const [selectedValue, setSelectedValue] = useState(false);
  const [value, setValue] = useState(false);

  const historyClick = () => {
    //////fix this for no tickets
    console.log(customer);
    console.log(customer.customer);
    if (customer.customer.ticketList) {
      setHistory(!history);
    }
  };
  const updateTicketClick = (value) => () => {
    // console.log(e);
    // e.preventDefault();
    console.log(value);
    if (value === ticketInfo) {
      setTicketInfo(false);
    } else {
      setTicketInfo(value);
    }
    // console.log(val2);

    // dispatch
    // dispatch(searchActions.updateTicket(e.target.value));
  };
  const addClick = () => {
    setAdd(!add);
    console.log(add);
  };
  const [inputs, setInputs] = useState({
    ticketId: "",
    ticketStatus: "",
    ticketTypeName: "",
  });
  const handleChange = (e) => {
    setInputs((prevState) => ({
      ...prevState,
      [e.target.name]: e.target.value,
    }));
  };
  const handleSubmitAddTicket = async (e) => {
    e.preventDefault();
    // console.log(inputs);
    // console.log(customer.customer._id);

    await axios
      .post("http://localhost:5000/api/addTicket", {
        _id: customer.customer._id,
        ticket: inputs,
      })
      .then((response) => {
        console.log(response);
        //   setCustomer(response.data);
      });
  };
  const addTicket = () => {
    return (
      <div>
        Add Ticket
        <form onSubmit={handleSubmitAddTicket}>
          <TextField
            name="ticketId"
            value={inputs.ticketId}
            onChange={handleChange}
            placeholder="id"
            type="text"
            variant="outlined"
          />
          <TextField
            name="ticketStatus"
            value={inputs.ticketStatus}
            onChange={handleChange}
            placeholder="ticketStatus"
            type="text"
            variant="outlined"
          />
          <TextField
            name="ticketTypeName"
            value={inputs.ticketTypeName}
            onChange={handleChange}
            placeholder="ticketTypeName"
            type="text"
            variant="outlined"
          />
          <Button type="submit">Submit</Button>
        </form>
      </div>
    );
  };
  const options = [
    { value: "ticketOption1", label: "TicketOption1" },
    { value: "ticketOption2", label: "TicketOption2" },
    { value: "ticketOption3", label: "TicketOption3" },
  ];

  // const onInputChange = (value) => {
  //   setValue(value);
  //   console.log(value);
  // };

  const onSelectChange = (value) => {
    setSelectedValue(value);
    // console.log(value);
  };
  const whenSelected = () => {
    return (
      <Select
        options={options}
        value={selectedValue}
        onChange={onSelectChange}
        // onInputChange={onInputChange}
      />
    );
  };
  const [dropDown, setDropDown] = useState([]);

  return (
    <div>
      <Button variant="outlined" size="small" onClick={historyClick}>
        Ticket History
      </Button>
      <Button variant="outlined" size="small" onClick={addClick}>
        AddTicket
      </Button>

      {history &&
        customer.customer.ticketList.map((index) => (
          <div className="ticketDiv" key={index._id}>
            {/* <h1 className="ticketHeader"> */}
            ticketId: {index.ticketId} ticketTypeName:
            {index.ticketType &&
              index.ticketType.ticketTypeName} ticketStatus:{" "}
            {index.ticketStatus + " "}
            <Button
              variant="outlined"
              size="small"
              onClick={updateTicketClick(index.ticketId)}
            >
              ViewExistingTicket
            </Button>
            {ticketInfo === index.ticketId ? whenSelected() : ""}
            {ticketInfo === index.ticketId &&
              selectedValue.value === "ticketOption1" && (
                <TicketForms dropDown={dropDown} setDropDown={setDropDown} />
              )}
            {/* {console.log(dropDown)} */}
            {updateTicket === index.ticketId && <UpdateTicket />}
            {/* </h1> */}
          </div>
        ))}

      {/* {add && addTicket()} */}
      {add && <TicketForms dropDown={dropDown} setDropDown={setDropDown} />}
    </div>
  );
};

export default CustomerOptions;
