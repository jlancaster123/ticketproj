import Login from "./Login";
import Webpage from "./Webpage";
import { useSelector } from "react-redux";
import style from "./App.css";
const App = () => {
  const isLoggedIn = useSelector((state) => state.login.isLoggedIn);
  console.log(isLoggedIn);
  return (
    <div>
      <h1 className="Title">Ticket Managing App inc</h1>
      {!isLoggedIn && <Login />}

      {isLoggedIn && <Webpage />}
    </div>
  );
};

export default App;
