const mongoose = require("mongoose");
const Ticket = require("./ticketModel");

const customerSchema = mongoose.Schema(
  {
    ticketTypeId: {
      type: String,
    },

    ticketTypeName: {
      type: String,
    },
    questions: {
      questionId: {
        type: String,
      },
      questionName: {
        type: String,
      },
      questionType: {
        type: String,
      },
      isRequired: {
        type: String,
      },
      questionText: {
        type: String,
      },
      questionOptions: {
        type: [],
      },
      answers: {
        type: [],
      },
    },
  },

  {
    timestamps: true,
  }
);
// const Customer = mongoose.model("customer", customerSchema);

module.exports = customerSchema;

// ticketType:[{
//     ticketTypeId, ticketTypeName, questions:[{questionId,questionName,questionType, isRequired, questionText, questionOptions:[], answers:[]}, ]}]
