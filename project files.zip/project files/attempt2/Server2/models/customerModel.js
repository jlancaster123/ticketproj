const mongoose = require("mongoose");
const Ticket = require("./ticketModel");

const customerSchema = mongoose.Schema(
  {
    customerId: {
      type: String,
      required: true,
    },

    firstName: {
      type: String,
      required: true,
    },
    lastName: {
      type: String,
      required: true,
    },
    ticketList: {
      type: [Ticket],
      default: undefined,
    },
  },

  {
    timestamps: true,
  }
);
const Customer = mongoose.model("Customers", customerSchema);

module.exports = Customer;
