const mongoose = require("mongoose");
const ticketTypeModel = require("./ticketTypeModel");

const ticketSchema = mongoose.Schema(
  {
    ticketId: {
      type: String,
      default: undefined,
    },
    // ticketType: [TicketType],
    ticketStatus: {
      type: String,
      default: undefined,
    },
    closedDate: {
      type: String,
      default: undefined,
    },
    createdDate: {
      type: String,
      default: undefined,
    },
    createdBy: {
      type: String,
      default: undefined,
    },
    lastModifiedDate: {
      type: String,
      default: undefined,
    },
    lastModifiedBy: {
      type: String,
      default: undefined,
    },
    isActive: {
      type: Boolean,
      default: undefined,
    },
    ticketType: ticketTypeModel,
  },

  {
    timestamps: true,
  }
);
//const Ticket = mongoose.model("ticket", ticketSchema);

module.exports = ticketSchema;

// Data

// ticket:[{ ticketId, ticketType, status, closedDate, createdDate, createdBy, lastModifiedDate, lastModifiedBy, isActive}]

// ticketType:[{
// ticketTypeId, ticketTypeName, questions:[{questionId,questionName,questionType, isRequired, questionText, questionOptions:[], answers:[]}, ]}]
