const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const { MongoClient } = require("mongodb");
const Customer = require("./models/customerModel");
// const Ticket = require("./models/ticketModel");
const dbURI =
  "mongodb+srv://test_user:test@cluster0.pi9jcsv.mongodb.net/?retryWrites=true&w=majority";
const app = express();
app.use(cors());
app.use(express.json());

const ticketTypeSample = {
  ticketTypeId: "1",
  ticketTypeName: "1",
  questions: {
    questionId: "1",
    questionName: "1",
    questionType: "1",
    isRequired: "1",
    questionText: "1",
    questionOptions: [],
    answers: [],
  },
};
const ticketSample = {
  ticketId: "1",
  ticketStatus: "1",
  closedDate: "1",
  createdDate: "1",
  createdBy: "1",
  lastModifiedDate: "1",
  lastModifiedBy: "1",
  isActive: true,
  ticketType: ticketTypeSample,
};
const ticketSample2 = {
  ticketId: "2",
  ticketStatus: "2",
  closedDate: "2",
  createdDate: "2",
  createdBy: "2",
  lastModifiedDate: "2",
  lastModifiedBy: "2",
  isActive: true,
  ticketType: ticketTypeSample,
};
const bill = new Customer({
  customerId: "5",
  firstName: "jerry",
  lastName: "smith",
  ticketList: [ticketSample, ticketSample2],
});

app.get("/api", (req, res) => {
  res.json({ users: ["userOne", "userTwo", "userThree"] });
});

app.get("/api/loadSample", (req, res) => {
  bill.save();
});

app.post("/api/addCustomer", (req, res) => {
  // console.log(req);
  console.log(req.body);
  // console.log(req.body.inputs.customerId);

  const temp = new Customer({
    customerId: req.body.inputs.customerId,
    firstName: req.body.inputs.firstName,
    lastName: req.body.inputs.lastName,
  });
  console.log(temp);
  temp.save();
  // Customer.find(req.body).then((result) => res.send(result));
});

app.post("/api/find", (req, res) => {
  // console.log(req);
  console.log(req.body);
  Customer.find(req.body, { firstName: 1, lastName: 1 }).then((result) => {
    res.send(result);
    console.log(result);
  });
});
app.post("/api/findTicket", (req, res) => {
  // console.log(req);
  console.log(req.body);
  Customer.find(req.body, { ticketList: 1 }).then((result) => {
    res.send(result);
    console.log(result);
  });
});

app.get("/api/findAndDisplay", (req, res) => {
  const person = Customer.find({ firstName: "bill" }).then((result) =>
    res.send(result)
  );
  // res.send(person);
  // console.log(person);
  // res.json(person);
});

app.post("/api/addTicket", async (req, res) => {
  // console.log("here");
  // console.log(req);
  // console.log(req.body);
  // console.log(req.body._id);
  // console.log(req.body.ticket);
  const ticketJson = {
    ticketId: req.body.ticket.ticketId,
    ticketStatus: req.body.ticket.ticketStatus,
    ticketType: { ticketTypeName: req.body.ticket.ticketStatus },
  };
  const temp = await Customer.findOneAndUpdate(
    { _id: req.body._id },
    { $push: { ticketList: ticketJson } }
  ).then((result) => res.send(JSON.stringify(result)));

  // const temp = await Customer.find({ _id: req.body._id });
});
app.post("/api/updateTicket", async (req, res) => {
  // console.log("here");
  // console.log(req);
  // console.log(req.body);
  // console.log(req.body._id);
  // console.log(req.body.ticket);
  const ticketJson = {
    ticketId: req.body.ticket.ticketId,
    ticketStatus: req.body.ticket.ticketStatus,
    ticketType: { ticketTypeName: req.body.ticket.ticketStatus },
  };
  // Customer.find({ _id: req.body._id }).then((result) => (
  //   result.update(
  //     { ticketList: ticketJson }

  //   )
  const temp = await Customer.findOneAndUpdate(
    { _id: req.body._id },
    { $set: { "ticketList.$.ticketId": "updateeee" } }
  ).then((result) => res.send(JSON.stringify(result)));

  // const temp = await Customer.findOneAndUpdate(
  //   { _id: req.body._id },
  //   { $push: { ticketList: ticketJson } }
  // ).then((result) => res.send(JSON.stringify(result)));

  // const temp = await Customer.find({ _id: req.body._id });
});

mongoose.connect(dbURI).then(
  console.log("connected to DB"),
  app.listen(5000, () => {
    console.log("Listening on port 5000");
  })
);
